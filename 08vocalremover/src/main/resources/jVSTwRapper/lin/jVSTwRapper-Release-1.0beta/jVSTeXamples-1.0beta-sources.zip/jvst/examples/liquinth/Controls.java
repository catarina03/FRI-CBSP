
package jvst.examples.liquinth;

public interface Controls {
	public int get_num_controllers();
	public String get_controller_name( int control );
	public int get_controller( int controller );
	public void set_controller( int controller, int value );
	public void set_mod_wheel( int value );
	public void set_pitch_wheel( int value );
}
